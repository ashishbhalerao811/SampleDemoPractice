package sampleDemos;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class HowVitalityWorks {

	public static void main(String[] args) throws Exception {
		System.setProperty("webdriver.chrome.driver", "D:\\Drivers\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		 
		driver.get("https://www.discovery.co.za/vitality/how-vitality-works");
		
		System.out.println(driver.getTitle());
		
		System.out.println("website opened");
		
		driver.manage().window().maximize();
		
		//First link
		driver.findElement(By.xpath("//a[contains(text(),'The Vitality Health programme')]")).click();
		
		Thread.sleep(3000);
		
		System.out.println("navigation page title is== "+driver.getTitle());
		
		Thread.sleep(3000);
		
		File src=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		try {
			FileUtils.copyFile(src, new File("D:\\POC\\DiscoveryPOC\\src\\output_vitalityWorks\\The Vitality Health programme.png"));
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		
		driver.navigate().back();
		driver.navigate().to("https://www.discovery.co.za/vitality/how-vitality-works");
		
		Thread.sleep(5000);
		
		System.out.println("Main page title is== "+driver.getTitle());

				//2nd link
		Thread.sleep(5000);
				driver.findElement(By.xpath("//a[contains(text(),'The Vitality Drive programme')]")).click();
				
				Thread.sleep(3000);
				
				System.out.println("navigation page title is== "+driver.getTitle());
				
				Thread.sleep(3000);
				
				File src1=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
				try {
					FileUtils.copyFile(src1, new File("D:\\POC\\DiscoveryPOC\\src\\output_vitalityWorks\\The Vitality Drive programme.png"));
				} catch (IOException e) {
					
					e.printStackTrace();
				}
				
				driver.navigate().back();
				driver.navigate().to("https://www.discovery.co.za/vitality/how-vitality-works");
				Thread.sleep(3000);
				
				System.out.println("Main page title is== "+driver.getTitle());
				
				//3rd link
				Thread.sleep(3000);
				
				driver.findElement(By.xpath("//a[contains(text(),'Health checks and assessments')]")).click();
				
				Thread.sleep(3000);
				
				System.out.println("navigation page title is== "+driver.getTitle());
				
				Thread.sleep(3000);
				
				File src2=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
				try {
					FileUtils.copyFile(src2, new File("D:\\POC\\DiscoveryPOC\\src\\output_vitalityWorks\\Health checks and assessments.png"));
				} catch (IOException e) {
					
					e.printStackTrace();
				}
				
				driver.navigate().back();
				driver.navigate().to("https://www.discovery.co.za/vitality/how-vitality-works");
				Thread.sleep(3000);
				
				System.out.println("Main page title is== "+driver.getTitle());
				
				//4th link
				Thread.sleep(3000);
				driver.findElement(By.xpath("//span[contains(text(),'Up to 33 000')]")).click();
				
				Thread.sleep(3000);
				
				System.out.println("navigation page title is== "+driver.getTitle());
				
				Thread.sleep(3000);
				
				File src3=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
				try {
					FileUtils.copyFile(src, new File("D:\\POC\\DiscoveryPOC\\src\\output_vitalityWorks\\Up to 33 000.png"));
				} catch (IOException e) {
					
					e.printStackTrace();
				}
				
				driver.navigate().back();
				driver.navigate().to("https://www.discovery.co.za/vitality/how-vitality-works");
				Thread.sleep(3000);
				
				System.out.println("Main page title is== "+driver.getTitle());
				
				//5th link
				Thread.sleep(3000);
				driver.findElement(By.xpath("//a[contains(text(),'Exercise')]")).click();
				
				Thread.sleep(3000);
				
				System.out.println("navigation page title is== "+driver.getTitle());
				
				Thread.sleep(3000);
				
				File src4=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
				try {
					FileUtils.copyFile(src4, new File("D:\\POC\\DiscoveryPOC\\src\\output_vitalityWorks\\Exercise.png"));
				} catch (IOException e) {
					
					e.printStackTrace();
				}
				
				driver.navigate().back();
				driver.navigate().to("https://www.discovery.co.za/vitality/how-vitality-works");
				Thread.sleep(3000);
				
				System.out.println("Main page title is== "+driver.getTitle());
				
				//6th link
				Thread.sleep(3000);
				driver.findElement(By.xpath("//span[contains(text(),'Up to 30 000')]")).click();
				
				Thread.sleep(3000);
				
				System.out.println("navigation page title is== "+driver.getTitle());
				
				Thread.sleep(3000);
				
				File src5=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
				try {
					FileUtils.copyFile(src5, new File("D:\\POC\\DiscoveryPOC\\src\\output_vitalityWorks\\Up to 30 000.png"));
				} catch (IOException e) {
					
					e.printStackTrace();
				}
				
				driver.navigate().back();
				driver.navigate().to("https://www.discovery.co.za/vitality/how-vitality-works");
				Thread.sleep(3000);
				
				System.out.println("Main page title is== "+driver.getTitle());
				
				//7th link
				Thread.sleep(3000);
				driver.findElement(By.xpath("//a[contains(text(),'Nutrition')]")).click();
				
				Thread.sleep(3000);
				
				System.out.println("navigation page title is== "+driver.getTitle());
				
				Thread.sleep(3000);
				
				File src6=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
				try {
					FileUtils.copyFile(src6, new File("D:\\POC\\DiscoveryPOC\\src\\output_vitalityWorks\\Nutrition.png"));
				} catch (IOException e) {
					
					e.printStackTrace();
				}
				
				driver.navigate().back();
				driver.navigate().to("https://www.discovery.co.za/vitality/how-vitality-works");
				Thread.sleep(3000);
				
				System.out.println("Main page title is== "+driver.getTitle());
				
				//8th link
				Thread.sleep(3000);
				driver.findElement(By.xpath("//span[contains(text(),'Up to 12 000')]")).click();
				
				Thread.sleep(3000);
				
				System.out.println("navigation page title is== "+driver.getTitle());
				
				Thread.sleep(3000);
				
				File src7=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
				try {
					FileUtils.copyFile(src7, new File("D:\\POC\\DiscoveryPOC\\src\\output_vitalityWorks\\Up to 12 000.png"));
				} catch (IOException e) {
					
					e.printStackTrace();
				}
				
				driver.navigate().back();
				driver.navigate().to("https://www.discovery.co.za/vitality/how-vitality-works");
				Thread.sleep(3000);
				
				System.out.println("Main page title is== "+driver.getTitle());
				
				//9th link
				Thread.sleep(3000);
				driver.findElement(By.xpath("//a[contains(text(),'Convert Vitality reward points')]")).click();
				
				Thread.sleep(3000);
				
				System.out.println("navigation page title is== "+driver.getTitle());
				
				Thread.sleep(3000);
				
				File src8=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
				try {
					FileUtils.copyFile(src8, new File("D:\\POC\\DiscoveryPOC\\src\\output_vitalityWorks\\Convert Vitality reward points.png"));
				} catch (IOException e) {
					
					e.printStackTrace();
				}
				
				driver.navigate().back();
				driver.navigate().to("https://www.discovery.co.za/vitality/how-vitality-works");
				Thread.sleep(3000);
				
				System.out.println("Main page title is== "+driver.getTitle());
				
				//10th link
				Thread.sleep(3000);
				driver.findElement(By.xpath("//span[contains(text(),'Up to 2 500')]")).click();
				
				Thread.sleep(3000);
				
				System.out.println("navigation page title is== "+driver.getTitle());
				
				Thread.sleep(3000);
				
				File src9=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
				try {
					FileUtils.copyFile(src9, new File("D:\\POC\\DiscoveryPOC\\src\\output_vitalityWorks\\Up to 2 500.png"));
				} catch (IOException e) {
					
					e.printStackTrace();
				}
				
				driver.navigate().back();
				driver.navigate().to("https://www.discovery.co.za/vitality/how-vitality-works");
				Thread.sleep(3000);
				
				System.out.println("Main page title is== "+driver.getTitle());
				
				//11th link
				Thread.sleep(3000);
				driver.findElement(By.xpath("//div[@class=\"row justify-content-center text-center\"]//a[contains(text(),'Vitality Active Rewards')]")).click();
				
				Thread.sleep(3000);
				
				System.out.println("navigation page title is== "+driver.getTitle());
				
				Thread.sleep(3000);
				
				File src10=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
				try {
					FileUtils.copyFile(src10, new File("D:\\POC\\DiscoveryPOC\\src\\output_vitalityWorks\\Vitality Active Rewards.png"));
				} catch (IOException e) {
					
					e.printStackTrace();
				}
				
				driver.navigate().back();
				driver.navigate().to("https://www.discovery.co.za/vitality/how-vitality-works");
				Thread.sleep(3000);
				
				System.out.println("Main page title is== "+driver.getTitle());
				
				//12th link
				Thread.sleep(3000);
				driver.findElement(By.xpath("//a[contains(text(),'Vitality Calculator')]")).click();
				
				Thread.sleep(3000);
				
				System.out.println("navigation page title is== "+driver.getTitle());
				
				Thread.sleep(3000);
				
				File src11=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
				try {
					FileUtils.copyFile(src11, new File("D:\\POC\\DiscoveryPOC\\src\\output_vitalityWorks\\Vitality Calculator.png"));
				} catch (IOException e) {
					
					e.printStackTrace();
				}
				
				driver.navigate().back();
				driver.navigate().to("https://www.discovery.co.za/vitality/how-vitality-works");
				Thread.sleep(3000);
				
				System.out.println("Main page title is== "+driver.getTitle());
				
				//13th link
				Thread.sleep(3000);
				driver.findElement(By.xpath("//a[contains(text(),'Get started')]")).click();
				
				Thread.sleep(3000);
				
				System.out.println("navigation page title is== "+driver.getTitle());
				
				Thread.sleep(3000);
				
				File src12=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
				try {
					FileUtils.copyFile(src12, new File("D:\\POC\\DiscoveryPOC\\src\\output_vitalityWorks\\Get started.png"));
				} catch (IOException e) {
					
					e.printStackTrace();
				}
				
				driver.navigate().back();
				driver.navigate().to("https://www.discovery.co.za/vitality/how-vitality-works");
				Thread.sleep(3000);
				
				System.out.println("Main page title is== "+driver.getTitle());
				
				//14th link
				Thread.sleep(3000);
				driver.findElement(By.xpath("//a[contains(text(),'health check')]")).click();
				
				Thread.sleep(3000);
				
				System.out.println("navigation page title is== "+driver.getTitle());
				
				Thread.sleep(3000);
				
				File src13=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
				try {
					FileUtils.copyFile(src13, new File("D:\\POC\\DiscoveryPOC\\src\\output_vitalityWorks\\health check.png"));
				} catch (IOException e) {
					
					e.printStackTrace();
				}
				
				driver.navigate().back();
				driver.navigate().to("https://www.discovery.co.za/vitality/how-vitality-works");
				Thread.sleep(3000);
				
				System.out.println("Main page title is== "+driver.getTitle());
				
				//15th link
				Thread.sleep(3000);
				driver.findElement(By.xpath("//a[contains(text(),'buying healthy food')]")).click();
				
				Thread.sleep(3000);
				
				System.out.println("navigation page title is== "+driver.getTitle());
				
				Thread.sleep(3000);
				
				File src14=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
				try {
					FileUtils.copyFile(src14, new File("D:\\POC\\DiscoveryPOC\\src\\output_vitalityWorks\\buying healthy food.png"));
				} catch (IOException e) {
					
					e.printStackTrace();
				}
				
				driver.navigate().back();
				driver.navigate().to("https://www.discovery.co.za/vitality/how-vitality-works");
				Thread.sleep(3000);
				
				System.out.println("Main page title is== "+driver.getTitle());
				
				//16th link
				Thread.sleep(3000);
				driver.findElement(By.xpath("//a[contains(text(),'getting physically active')]")).click();
				
				Thread.sleep(3000);
				
				System.out.println("navigation page title is== "+driver.getTitle());
				
				Thread.sleep(3000);
				
				File src15=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
				try {
					FileUtils.copyFile(src15, new File("D:\\POC\\DiscoveryPOC\\src\\output_vitalityWorks\\getting physically active.png"));
				} catch (IOException e) {
					
					e.printStackTrace();
				}
				
				driver.navigate().back();
				driver.navigate().to("https://www.discovery.co.za/vitality/how-vitality-works");
				Thread.sleep(3000);
				
				System.out.println("Main page title is== "+driver.getTitle());
				
				//17th link
				Thread.sleep(3000);
				driver.findElement(By.xpath("//a[contains(text(),'variety of rewards')]")).click();
				
				Thread.sleep(3000);
				
				System.out.println("navigation page title is== "+driver.getTitle());
				
				Thread.sleep(3000);
				
				File src16=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
				try {
					FileUtils.copyFile(src16, new File("D:\\POC\\DiscoveryPOC\\src\\output_vitalityWorks\\variety of rewards.png"));
				} catch (IOException e) {
					
					e.printStackTrace();
				}
				
				driver.navigate().back();
				driver.navigate().to("https://www.discovery.co.za/vitality/how-vitality-works");
				Thread.sleep(3000);
				
				System.out.println("Main page title is== "+driver.getTitle());
				
				//18th link
				Thread.sleep(3000);
				driver.findElement(By.xpath("//a[contains(text(),'Driver behaviour')]")).click();
				
				Thread.sleep(3000);
				
				System.out.println("navigation page title is== "+driver.getTitle());
				
				Thread.sleep(3000);
				
				File src17=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
				try {
					FileUtils.copyFile(src17, new File("D:\\POC\\DiscoveryPOC\\src\\output_vitalityWorks\\Driver behaviour.png"));
				} catch (IOException e) {
					
					e.printStackTrace();
				}
				
				driver.navigate().back();
				driver.navigate().to("https://www.discovery.co.za/vitality/how-vitality-works");
				Thread.sleep(3000);
				
				System.out.println("Main page title is== "+driver.getTitle());
				
				//19th link
				Thread.sleep(3000);
				driver.findElement(By.xpath("//span[contains(text(),'Up to 900')]")).click();
				
				Thread.sleep(3000);
				
				System.out.println("navigation page title is== "+driver.getTitle());
				
				Thread.sleep(3000);
				
				File src18=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
				try {
					FileUtils.copyFile(src18, new File("D:\\POC\\DiscoveryPOC\\src\\output_vitalityWorks\\Up to 900.png"));
				} catch (IOException e) {
					
					e.printStackTrace();
				}
				
				driver.navigate().back();
				driver.navigate().to("https://www.discovery.co.za/vitality/how-vitality-works");
				Thread.sleep(3000);
				
				System.out.println("Main page title is== "+driver.getTitle());
				
				//20th link
				Thread.sleep(3000);
				driver.findElement(By.xpath("//a[contains(text(),'Knowledge and awareness')]")).click();
				
				Thread.sleep(3000);
				
				System.out.println("navigation page title is== "+driver.getTitle());
				
				Thread.sleep(3000);
				
				File src19=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
				try {
					FileUtils.copyFile(src19, new File("D:\\POC\\DiscoveryPOC\\src\\output_vitalityWorks\\Knowledge and awareness.png"));
				} catch (IOException e) {
					
					e.printStackTrace();
				}
				
				driver.navigate().back();
				driver.navigate().to("https://www.discovery.co.za/vitality/how-vitality-works");
				Thread.sleep(3000);
				
				System.out.println("Main page title is== "+driver.getTitle());
				
				//21th link
				Thread.sleep(3000);
				driver.findElement(By.xpath("//span[contains(text(),'Up to 350')]")).click();
				
				Thread.sleep(3000);
				
				System.out.println("navigation page title is== "+driver.getTitle());
				
				Thread.sleep(3000);
				
				File src20=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
				try {
					FileUtils.copyFile(src20, new File("D:\\POC\\DiscoveryPOC\\src\\output_vitalityWorks\\Up to 350.png"));
				} catch (IOException e) {
					
					e.printStackTrace();
				}
				
				driver.navigate().back();
				driver.navigate().to("https://www.discovery.co.za/vitality/how-vitality-works");
				Thread.sleep(3000);
				
				System.out.println("Main page title is== "+driver.getTitle());
				
				//22th link
				Thread.sleep(3000);
				WebElement ele = driver.findElement(By.xpath("//div[@class=\"container\"]//h2[contains(text(),'Get rewarded for living well. Join Vitality')]/../../..//input[@name=\"firstName\"]"));
				ele.sendKeys("John");
				
				WebElement ele1 = driver.findElement(By.xpath("//div[@class=\"container\"]//h2[contains(text(),'Get rewarded for living well. Join Vitality')]/../../..//input[@name=\"lastName\"]"));
				ele1.sendKeys("Carter");
				
				WebElement ele2 = driver.findElement(By.xpath("//div[@class=\"container\"]//h2[contains(text(),'Get rewarded for living well. Join Vitality')]/../../..//input[@name=\"mobileNumber\"]"));
				ele2.sendKeys("32654984");
				
				WebElement ele3 = driver.findElement(By.xpath("//div[@class=\"container\"]//h2[contains(text(),'Get rewarded for living well. Join Vitality')]/../../..//input[@name=\"idNumber\"]"));
				ele3.sendKeys("id65489");
				
				Thread.sleep(7000);
				driver.findElement(By.xpath("//div[@class=\"container\"]//h2[contains(text(),'Get rewarded for living well. Join Vitality')]/../../..//button[contains(text(),\"Log in to activate\")]")).click();
				
				Thread.sleep(7000);
				driver.findElement(By.xpath("//div[@class=\"container\"]//h2[contains(text(),'Get rewarded for living well. Join Vitality')]/../../..//span[contains(text(),\"Call me back\")]/../..")).click();
				
				Thread.sleep(3000);
				
				System.out.println("navigation page title is== "+driver.getTitle());
				
				Thread.sleep(3000);
				
				File src21=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
				try {
					FileUtils.copyFile(src21, new File("D:\\POC\\DiscoveryPOC\\src\\output_vitalityWorks\\lowerMostFrame.png"));
				} catch (IOException e) {
					
					e.printStackTrace();
				}
				
				driver.navigate().back();
				driver.navigate().to("https://www.discovery.co.za/vitality/how-vitality-works");
				Thread.sleep(3000);
				
				System.out.println("Main page title is== "+driver.getTitle());
				
				
				//23rd link
				Thread.sleep(3000);
				WebElement element = driver.findElement(By.xpath("//div[@class=\"container\"]//h2[contains(text(),'Get a car or home insurance quote today!')]/../../../..//input[@name=\"firstName\"]"));
				element.sendKeys("John");
				
				WebElement element1 = driver.findElement(By.xpath("//div[@class=\"container\"]//h2[contains(text(),'Get a car or home insurance quote today!')]/../../../..//input[@name=\"lastName\"]"));
				element1.sendKeys("Carter");
				
				WebElement element2 = driver.findElement(By.xpath("//div[@class=\"container\"]//h2[contains(text(),'Get a car or home insurance quote today!')]/../../../..//input[@name=\"mobileNumber\"]"));
				element2.sendKeys("32654984");
				
				WebElement element3 = driver.findElement(By.xpath("//div[@class=\"container\"]//h2[contains(text(),'Get a car or home insurance quote today!')]/../../../..//input[@name=\"idNumber\"]"));
				element3.sendKeys("id65489");
				
				Thread.sleep(7000);
				driver.findElement(By.xpath("//div[@class=\"container\"]//h2[contains(text(),'Get a car or home insurance quote today!')]/../../../..//span[contains(text(),\"Call me back\")]/../..")).click();
				
				Thread.sleep(7000);
				
				System.out.println("navigation page title is== "+driver.getTitle());
				
				Thread.sleep(3000);
				
				File src22=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
				try {
					FileUtils.copyFile(src22, new File("D:\\POC\\DiscoveryPOC\\src\\output_vitalityWorks\\lowerMostFrame.png"));
				} catch (IOException e) {
					
					e.printStackTrace();
				}
				
				
				
				driver.quit();
		
		
		

	}

}
