package sampleDemos;
import java.io.File;
import java.io.IOException;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;



public class JoinTodayPage {

	public static void main(String[] args) throws Exception   {
		
		System.setProperty("webdriver.chrome.driver", "D:\\Drivers\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		 
		driver.get("https://www.discovery.co.za/vitality/join-today");
		
		System.out.println(driver.getTitle());
		
		System.out.println("website opened");
		
		driver.manage().window().maximize();
		
		//First link
		driver.findElement(By.xpath("//a[contains(text(),'half-price movies')]")).click();
		
		Thread.sleep(3000);
		
		System.out.println("navigation page title is== "+driver.getTitle());
		
		Thread.sleep(3000);
		
		File src=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		try {
			FileUtils.copyFile(src, new File("D:\\POC\\DiscoveryPOC\\src\\output\\half-price movies.png"));
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		
		driver.navigate().back();
		
		Thread.sleep(3000);
		
		System.out.println("Main page title is== "+driver.getTitle());

				//2nd link
				driver.findElement(By.xpath("//a[contains(text(),'flight savings')]")).click();
				
				Thread.sleep(3000);
				
				System.out.println("navigation page title is== "+driver.getTitle());
				
				Thread.sleep(3000);
				
				File src1=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
				try {
					FileUtils.copyFile(src1, new File("D:\\POC\\DiscoveryPOC\\src\\output\\flight savings.png"));
				} catch (IOException e) {
					
					e.printStackTrace();
				}
				
				driver.navigate().back();
				
				Thread.sleep(3000);
				
				System.out.println("Main page title is== "+driver.getTitle());
				
				//3rd link
				driver.findElement(By.xpath("//a[contains(text(),\"cash back\")]")).click();
				
				Thread.sleep(3000);
				
				System.out.println("navigation page title is== "+driver.getTitle());
				
				Thread.sleep(3000);
				
				File src2=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
				try {
					FileUtils.copyFile(src2, new File("D:\\POC\\DiscoveryPOC\\src\\output\\cash back.png"));
				} catch (IOException e) {
					
					e.printStackTrace();
				}
				
				driver.navigate().back();
				
				Thread.sleep(3000);
				
				System.out.println("Main page title is== "+driver.getTitle());
				
				//4th link
				driver.findElement(By.xpath("//a[contains(text(),\"fuel savings\")]")).click();
				
				Thread.sleep(3000);
				
				System.out.println("navigation page title is== "+driver.getTitle());
				
				Thread.sleep(3000);
				
				File src3=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
				try {
					FileUtils.copyFile(src, new File("D:\\POC\\DiscoveryPOC\\src\\output\\fuel savings.png"));
				} catch (IOException e) {
					
					e.printStackTrace();
				}
				
				driver.navigate().back();
				
				Thread.sleep(3000);
				
				System.out.println("Main page title is== "+driver.getTitle());
				
				//5th link
				driver.findElement(By.xpath("//a[contains(text(),\"weekly rewards and more\")]")).click();
				
				Thread.sleep(3000);
				
				System.out.println("navigation page title is== "+driver.getTitle());
				
				Thread.sleep(3000);
				
				File src4=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
				try {
					FileUtils.copyFile(src4, new File("D:\\POC\\DiscoveryPOC\\src\\output\\weekly rewards and more.png"));
				} catch (IOException e) {
					
					e.printStackTrace();
				}
				
				driver.navigate().back();
				
				Thread.sleep(3000);
				
				System.out.println("Main page title is== "+driver.getTitle());
				
				//6th link
				driver.findElement(By.xpath("//a[contains(text(),\"enjoying thousands of rewards\")]")).click();
				
				Thread.sleep(3000);
				
				System.out.println("navigation page title is== "+driver.getTitle());
				
				Thread.sleep(3000);
				
				File src5=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
				try {
					FileUtils.copyFile(src5, new File("D:\\POC\\DiscoveryPOC\\src\\output\\enjoying thousands of rewards.png"));
				} catch (IOException e) {
					
					e.printStackTrace();
				}
				
				driver.navigate().back();
				
				Thread.sleep(3000);
				
				System.out.println("Main page title is== "+driver.getTitle());
				
				//7th link
				driver.findElement(By.xpath("//a[contains(text(),\"Vitality premiums for 2019\")]")).click();
				
				Thread.sleep(3000);
				
				System.out.println("navigation page title is== "+driver.getTitle());
				
				Thread.sleep(3000);
				
				File src6=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
				try {
					FileUtils.copyFile(src6, new File("D:\\POC\\DiscoveryPOC\\src\\output\\Vitality premiums for 2019.png"));
				} catch (IOException e) {
					
					e.printStackTrace();
				}
				
				driver.navigate().back();
				
				Thread.sleep(3000);
				
				System.out.println("Main page title is== "+driver.getTitle());
				
				//8th link
				driver.findElement(By.xpath("//a[contains(text(),\"Learn more\") and @href='/vitality/vitality-active']")).click();
				
				Thread.sleep(3000);
				
				System.out.println("navigation page title is== "+driver.getTitle());
				
				Thread.sleep(3000);
				
				File src7=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
				try {
					FileUtils.copyFile(src7, new File("D:\\POC\\DiscoveryPOC\\src\\output\\vitality-active.png"));
				} catch (IOException e) {
					
					e.printStackTrace();
				}
				
				driver.navigate().back();
				
				Thread.sleep(3000);
				
				System.out.println("Main page title is== "+driver.getTitle());
				
				//9th link
				driver.findElement(By.xpath("//a[contains(text(),\"Learn more\") and @href='/vitality/upgrade-to-vitality-purple']")).click();
				
				Thread.sleep(3000);
				
				System.out.println("navigation page title is== "+driver.getTitle());
				
				Thread.sleep(3000);
				
				File src8=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
				try {
					FileUtils.copyFile(src8, new File("D:\\POC\\DiscoveryPOC\\src\\output\\upgrade-to-vitality-purple.png"));
				} catch (IOException e) {
					
					e.printStackTrace();
				}
				
				driver.navigate().back();
				
				Thread.sleep(3000);
				
				System.out.println("Main page title is== "+driver.getTitle());
				
				//10th link
				driver.findElement(By.xpath("//a[contains(text(),\"Learn more\") and @href='/vitality/how-vitality-move-works']")).click();
				
				Thread.sleep(3000);
				
				System.out.println("navigation page title is== "+driver.getTitle());
				
				Thread.sleep(3000);
				
				File src9=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
				try {
					FileUtils.copyFile(src9, new File("D:\\POC\\DiscoveryPOC\\src\\output\\how-vitality-move-works.png"));
				} catch (IOException e) {
					
					e.printStackTrace();
				}
				
				driver.navigate().back();
				
				Thread.sleep(3000);
				
				System.out.println("Main page title is== "+driver.getTitle());
				
				//11th link
				driver.findElement(By.xpath("//div[@class=\"row hidden-md-down text-center\"]//child::a[@href='/vitality/apple-watch']//child::img")).click();
				
				Thread.sleep(3000);
				
				System.out.println("navigation page title is== "+driver.getTitle());
				
				Thread.sleep(3000);
				
				File src10=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
				try {
					FileUtils.copyFile(src10, new File("D:\\POC\\DiscoveryPOC\\src\\output\\apple-watch.png"));
				} catch (IOException e) {
					
					e.printStackTrace();
				}
				
				driver.navigate().back();
				
				Thread.sleep(3000);
				
				System.out.println("Main page title is== "+driver.getTitle());
				
				//12th link
				driver.findElement(By.xpath("//div[@class=\"row hidden-md-down text-center\"]//child::a[@href='/reward-partners/british-airways-international']//child::img")).click();
				
				Thread.sleep(3000);
				
				System.out.println("navigation page title is== "+driver.getTitle());
				
				Thread.sleep(3000);
				
				File src11=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
				try {
					FileUtils.copyFile(src11, new File("D:\\POC\\DiscoveryPOC\\src\\output\\british-airways-international.png"));
				} catch (IOException e) {
					
					e.printStackTrace();
				}
				
				driver.navigate().back();
				
				Thread.sleep(3000);
				
				System.out.println("Main page title is== "+driver.getTitle());
				
				//13th link
				driver.findElement(By.xpath("//div[@class=\"row hidden-md-down text-center\"]//child::a[@href='/reward-partners/kulula']//child::img")).click();
				
				Thread.sleep(3000);
				
				System.out.println("navigation page title is== "+driver.getTitle());
				
				Thread.sleep(3000);
				
				File src12=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
				try {
					FileUtils.copyFile(src12, new File("D:\\POC\\DiscoveryPOC\\src\\output\\reward-partners/kulula.png"));
				} catch (IOException e) {
					
					e.printStackTrace();
				}
				
				driver.navigate().back();
				
				Thread.sleep(3000);
				
				System.out.println("Main page title is== "+driver.getTitle());
				
				//14th link
				driver.findElement(By.xpath("//div[@class=\"row hidden-md-down text-center\"]//child::a[@href='/reward-partners/woolworths']//child::img")).click();
				
				Thread.sleep(3000);
				
				System.out.println("navigation page title is== "+driver.getTitle());
				
				Thread.sleep(3000);
				
				File src13=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
				try {
					FileUtils.copyFile(src13, new File("D:\\POC\\DiscoveryPOC\\src\\output\\woolworths.png"));
				} catch (IOException e) {
					
					e.printStackTrace();
				}
				
				driver.navigate().back();
				
				Thread.sleep(3000);
				
				System.out.println("Main page title is== "+driver.getTitle());
				
				//15th link
				driver.findElement(By.xpath("//div[@class=\"row hidden-md-down text-center\"]//child::a[@href='/portal/individual/improve-health-healthyfood']//child::img")).click();
				
				Thread.sleep(3000);
				
				System.out.println("navigation page title is== "+driver.getTitle());
				
				Thread.sleep(3000);
				
				File src14=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
				try {
					FileUtils.copyFile(src14, new File("D:\\POC\\DiscoveryPOC\\src\\output\\improve-health-healthyfood.png"));
				} catch (IOException e) {
					
					e.printStackTrace();
				}
				
				driver.navigate().back();
				
				Thread.sleep(3000);
				
				System.out.println("Main page title is== "+driver.getTitle());
				
				//16th link
				driver.findElement(By.xpath("//div[@class=\"row hidden-md-down text-center\"]//child::a[@href='/vitality/ster-kinekor']//child::img")).click();
				
				Thread.sleep(3000);
				
				System.out.println("navigation page title is== "+driver.getTitle());
				
				Thread.sleep(3000);
				
				File src15=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
				try {
					FileUtils.copyFile(src15, new File("D:\\POC\\DiscoveryPOC\\src\\output\\ster-kinekor.png"));
				} catch (IOException e) {
					
					e.printStackTrace();
				}
				
				driver.navigate().back();
				
				Thread.sleep(3000);
				
				System.out.println("Main page title is== "+driver.getTitle());
				
				//17th link
				driver.findElement(By.xpath("//div[@class=\"row hidden-md-down text-center\"]//child::a[@href='/vitality/virgin-active']//child::img")).click();
				
				Thread.sleep(3000);
				
				System.out.println("navigation page title is== "+driver.getTitle());
				
				Thread.sleep(3000);
				
				File src16=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
				try {
					FileUtils.copyFile(src16, new File("D:\\POC\\DiscoveryPOC\\src\\output\\virgin-active.png"));
				} catch (IOException e) {
					
					e.printStackTrace();
				}
				
				driver.navigate().back();
				
				Thread.sleep(3000);
				
				System.out.println("Main page title is== "+driver.getTitle());
				
				//18th link
				driver.findElement(By.xpath("//div[@class=\"row hidden-md-down text-center\"]//child::a[@href='/vitality/planet-fitness']//child::img")).click();
				
				Thread.sleep(3000);
				
				System.out.println("navigation page title is== "+driver.getTitle());
				
				Thread.sleep(3000);
				
				File src17=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
				try {
					FileUtils.copyFile(src17, new File("D:\\POC\\DiscoveryPOC\\src\\output\\planet-fitness.png"));
				} catch (IOException e) {
					
					e.printStackTrace();
				}
				
				driver.navigate().back();
				
				Thread.sleep(3000);
				
				System.out.println("Main page title is== "+driver.getTitle());
				
		driver.quit();
		
		
		
		

		
//		List<WebElement> linksize = driver.findElements(By.tagName("a")); 
//		
//		linksCount = linksize.size();
//		
//		System.out.println("Total no of links Available: "+linksCount);
//		
//		links= new String[linksCount];
//		
//		System.out.println("List of links Available: "); 
//		
//		// print all the links from webpage 
//		for(int i=0;i<linksCount;i++)
//		{
//			
//		links[i] = linksize.get(i).getAttribute("href");
//		System.out.println(all_links.get(i).getAttribute("href"));
//		} 
//		// navigate to each Link on the webpage
//		for(int i=0;i<linksCount;i++)
//		{
//		driver.navigate().to(links[i]);
//		Thread.sleep(3000);
//		}
		
		
		
		
		//driver.navigate().back();
		//driver.close();
		
		
		
		
		
		
		
		
		
		
		

	}

}
