package sampleDemos;
import java.io.File;
import java.io.IOException;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;



public class JoinTodayPage2 {

	public static void main(String[] args) throws Exception   {
		
		System.setProperty("webdriver.chrome.driver", "D:\\Drivers\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		
		driver.get("https://www.discovery.co.za/vitality/how-vitality-works");
		
		System.out.println(driver.getTitle());
		
		System.out.println("website opened");
		
		driver.manage().window().maximize();
		
		driver.findElement(By.xpath("//span[contains(text(),'Up to 350')]")).click();
		
//		JavascriptExecutor jExecutor=
//		WebElement webElement = driver.findElement(By.xpath("//div[@id='main-container']//h2[contains(text(),'Not a Vitality member?')]/../../..//input[@name='firstName']"));
//		
//		jExecutor.executeScript("arguments[0].setAttribute('style','border:3px dotted #f00');", webElement);
		
//		Thread.sleep(3000);
//		
//		System.out.println("navigation page title is== "+driver.getTitle());
//		
//		//driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
//		
//		File src=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
//		try {
//			FileUtils.copyFile(src, new File("D:\\POC\\DiscoveryPOC\\src\\output3\\index.png"));
//		} catch (IOException e) {
//			
//			e.printStackTrace();
//		}
//		
//		Thread.sleep(3000);
//		
//		driver.navigate().back();
//		
//		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
//		
//		System.out.println("Main page title is== "+driver.getTitle());
//
//		driver.quit();
		
		
		
		
		
		
		
		
		

	}

}
