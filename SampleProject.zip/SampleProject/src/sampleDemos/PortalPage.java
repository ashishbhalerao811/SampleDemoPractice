package sampleDemos;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

public class PortalPage {

	private static final TimeUnit SECONDS = null;

	public static void main(String[] args) throws Exception {
		System.setProperty("webdriver.chrome.driver", "D:\\Drivers\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		
		driver.get("https://www.discovery.co.za/portal/");
		
		System.out.println("website opened");
		
		driver.manage().window().maximize();
		
		driver.findElement(By.xpath("//a[@id=\"topnav-vitality\" and @href='#']")).click();
		
		Thread.sleep(7000);
		
		
		driver.findElement(By.xpath("//div[@class='container navigation-inner-container']//child::a[@id='topnav-sl-vitality-join-today']")).click();

//		List<WebElement> list = driver.findElements(By.tagName("iframe"));
//		int count=list.size();
//		System.out.println(count);
//		Thread.sleep(10000);
//		for(int i=0; i<count; i++) {
//			
//			System.out.println(list.get(i).getText());
//			
//		}
		
		System.out.println(driver.findElement(By.xpath("//h2[contains(text(),\"Not a Vitality member? Join today and only pay R799 to join the gym.\")]")).getText());
		
		Thread.sleep(5000);
//		driver.findElement(By.xpath("//*[@id=\"submitBtn3833\"]")).click();
		
		
		
		
		//		
		
//		driver.navigate().back();
		
		
//		driver.switchTo().frame(1);
//		
//		WebElement ele=driver.findElement(By.xpath("//form[@id='leadForm1865']//child::div[@class='row justify-content-center']//child::div[@class='col-xl-4 col-lg-4  lg-m-b-1 xl-m-b-0']//child::button"));
//		Thread.sleep(5000);
//		ele.click();

//		driver.switchTo().frame(5);
		//Thread.sleep(5000);
		
		//WebElement ele=driver.findElement(By.xpath("//input[@id=\"firstName1865\"]"));

		
//		WebDriverWait wait=new WebDriverWait(driver, 60);
//		WebElement ele;
//		ele = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id=\\\"firstName1865\\\"]")));
//		
		 // Waiting 30 seconds for an element to be present on the page, checking

		  // for its presence once every 5 seconds.

//		  Wait wait = new FluentWait(driver)
//
//		    .withTimeout(30, SECONDS)
//
//		    .pollingEvery(5, SECONDS)
//
//		    .ignoring(NoSuchElementException.class);

//				  WebElement foo = wait.until(new Function() {
//
//				    public WebElement apply(WebDriver driver) {
//
//				    return driver.findElement(By.id("foo"));
//
//				    }
//
//				   });
		  
//		ele.sendKeys("abc");
		
		//Thread.sleep(5000);

//
//		driver.findElement(By.xpath("//input[@id=\"lastName1865\"]")).sendKeys("efg");
//		
//		driver.findElement(By.xpath("//input[@id=\"mobileNumber1865\"]")).sendKeys("1234567890");
//		
//		driver.findElement(By.xpath("//input[@id=\"idNumber1865\"]")).sendKeys("45689");
//		
//		driver.findElement(By.xpath("//form[@id='leadForm1865']//child::div[@class='row justify-content-center']//child::div[@class='col-xl-4 col-lg-4  lg-m-b-1 xl-m-b-0']//child::button")).click();

//		// Create instance of Javascript executor
//
//		JavascriptExecutor je = (JavascriptExecutor) driver;
//
//		//Identify the WebElement which will appear after scrolling down
//
//		WebElement element = driver.findElement(By.xpath("//*[@id=\"submitBtn3096\"]"));
//
//		// now execute query which actually will scroll until that element is not appeared on page.
//
//		je.executeScript("arguments[0].scrollIntoView(true);",element);
		

		//driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
//		List<WebElement> list = driver.findElements(By.tagName("iframe"));
//		int count=list.size();
//		System.out.println(count);
//		Thread.sleep(10000);
//		for(int i=0; i<count; i++) {
//			
//			System.out.println(list.get(i).getText());
//		}
//		
		
//		Thread.sleep(5000);
//		WebElement ele=driver.findElement(By.xpath("//*[@id=\"submitBtn3096\"]/div/span[2]"));
		
//		driver.switchTo().frame(1);
//		WebDriverWait wait=new WebDriverWait(driver, 30);
//		WebElement ele;
//		ele = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\\\"submitBtn3096\\\"]/div/span[2]")));
//		ele.click();
		
		
//		Actions act=new Actions(driver);
//		act.moveToElement(ele).click();
		
//		System.out.println("clicked on element");
//		
//		Thread.sleep(3000);
//		JavascriptExecutor je=(JavascriptExecutor)driver;
//		je.executeScript("arguments[0].scrollIntoView(true);", ele);
//		
//		
//		System.out.println("clicked on call me button");
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		driver.close();
		System.out.println("website closed");

		
		
	}

}
