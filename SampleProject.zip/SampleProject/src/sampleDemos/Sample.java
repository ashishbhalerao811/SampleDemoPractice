package sampleDemos;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Sample {

	public static void main(String[] args) throws Exception {
		System.setProperty("webdriver.chrome.driver", "D:\\Drivers\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.discovery.co.za/vitality/join-today");
		driver.manage().window().maximize();
		Thread.sleep(7000);
		//lower frame
		WebElement ele = driver.findElement(By.xpath("//div[@class='col-md-12 pt-2 bg-vitality base pb-2']//h2[contains(text(),'Get rewarded for living well. Join Vitality')]//..//..//..//input[@name='firstName']"));
		ele.sendKeys("John");
		
		driver.findElement(By.xpath("//div[@class='col-md-12 pt-2 bg-vitality base pb-2']//h2[contains(text(),'Get rewarded for living well. Join Vitality')]//..//..//..//input[@name='lastName']")).sendKeys("White");
		
		driver.findElement(By.xpath("//div[@class='col-md-12 pt-2 bg-vitality base pb-2']//h2[contains(text(),'Get rewarded for living well. Join Vitality')]//..//..//..//input[@name='mobileNumber']"))
		.sendKeys("1234567");
		
		driver.findElement(By.xpath("//div[@class='col-md-12 pt-2 bg-vitality base pb-2']//h2[contains(text(),'Get rewarded for living well. Join Vitality')]//..//..//..//input[@name='idNumber']"))
		.sendKeys("id896543");
		
		driver.findElement(By.xpath("//div[@class='col-md-12 pt-2 bg-vitality base pb-2']//h2[contains(text(),'Get rewarded for living well. Join Vitality')]//..//..//..//button[contains(text(),'Log in to activate')]")).click();

		
		driver.findElement(By.xpath("//div[@class='col-md-12 pt-2 bg-vitality base pb-2']//h2[contains(text(),'Get rewarded for living well. Join Vitality')]//..//..//..//span[contains(text(),'Call me back')]/../..")).click();
		
		
		
		//upper frame
		
//		WebElement ele1 = driver.findElement(By.xpath("//div[@id='main-container']//h2[contains(text(),'Not a Vitality member?')]/../../..//input[@name='lastName']"));
//		ele1.sendKeys("Hardy");
//		
//		WebElement ele2 = driver.findElement(By.xpath("//div[@id='main-container']//h2[contains(text(),'Not a Vitality member?')]/../../..//input[@name='mobileNumber']"));
//		ele2.sendKeys("119785313");
//		
//		WebElement ele3 = driver.findElement(By.xpath("//div[@id='main-container']//h2[contains(text(),'Not a Vitality member?')]/../../..//input[@name='idNumber']"));
//		ele3.sendKeys("jrqlp1234q");
//		
//		Thread.sleep(7000);
//		WebElement ele4 = driver.findElement(By.xpath("//div[@id='main-container']//h2[contains(text(),'Not a Vitality member?')]/../../..//button[contains(text(),'Log in to activate')]"));
//		ele4.click();
//		
//		Thread.sleep(7000);
//		WebElement ele5 = driver.findElement(By.xpath("//div[@id='main-container']//h2[contains(text(),'Not a Vitality member?')]/../../..//span[contains(text(),'Call me back')]/../.."));
//		ele5.click();
//		
//		Thread.sleep(7000);

	}

}
