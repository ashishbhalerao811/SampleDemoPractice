package sampleDemos;
import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class SampleVitalityWorks {

	public static void main(String[] args) throws Exception {
		System.setProperty("webdriver.chrome.driver", "D:\\Drivers\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.discovery.co.za/vitality/how-vitality-works");
		driver.manage().window().maximize();
		Thread.sleep(7000);
		//lower frame
		WebElement ele = driver.findElement(By.xpath("//div[@class=\"container\"]//h2[contains(text(),'Get rewarded for living well. Join Vitality')]/../../..//input[@name=\"firstName\"]"));
		ele.sendKeys("John");
		
		WebElement ele1 = driver.findElement(By.xpath("//div[@class=\"container\"]//h2[contains(text(),'Get rewarded for living well. Join Vitality')]/../../..//input[@name=\"lastName\"]"));
		ele1.sendKeys("Carter");
		
		WebElement ele2 = driver.findElement(By.xpath("//div[@class=\"container\"]//h2[contains(text(),'Get rewarded for living well. Join Vitality')]/../../..//input[@name=\"mobileNumber\"]"));
		ele2.sendKeys("32654984");
		
		WebElement ele3 = driver.findElement(By.xpath("//div[@class=\"container\"]//h2[contains(text(),'Get rewarded for living well. Join Vitality')]/../../..//input[@name=\"idNumber\"]"));
		ele3.sendKeys("id65489");
		
		Thread.sleep(7000);
		driver.findElement(By.xpath("//div[@class=\"container\"]//h2[contains(text(),'Get rewarded for living well. Join Vitality')]/../../..//button[contains(text(),\"Log in to activate\")]")).click();
		
		Thread.sleep(7000);
		driver.findElement(By.xpath("//div[@class=\"container\"]//h2[contains(text(),'Get rewarded for living well. Join Vitality')]/../../..//span[contains(text(),\"Call me back\")]/../..")).click();
		
		Thread.sleep(3000);
		
		System.out.println("navigation page title is== "+driver.getTitle());
		
		Thread.sleep(3000);
		
		File src21=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		try {
			FileUtils.copyFile(src21, new File("D:\\POC\\DiscoveryPOC\\src\\output_vitalityWorks\\Up to 350.png"));
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		
		
	}

}
