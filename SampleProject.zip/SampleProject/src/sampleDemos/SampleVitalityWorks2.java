package sampleDemos;
import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class SampleVitalityWorks2 {

	public static void main(String[] args) throws Exception {
		System.setProperty("webdriver.chrome.driver", "D:\\Drivers\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.discovery.co.za/vitality/how-vitality-works");
		driver.manage().window().maximize();
		Thread.sleep(7000);
		//lower frame


		WebElement element = driver.findElement(By.xpath("//div[@class=\"container\"]//h2[contains(text(),'Get a car or home insurance quote today!')]/../../../..//input[@name=\"firstName\"]"));
		element.sendKeys("John");
		
		WebElement element1 = driver.findElement(By.xpath("//div[@class=\"container\"]//h2[contains(text(),'Get a car or home insurance quote today!')]/../../../..//input[@name=\"lastName\"]"));
		element1.sendKeys("Carter");
		
		WebElement element2 = driver.findElement(By.xpath("//div[@class=\"container\"]//h2[contains(text(),'Get a car or home insurance quote today!')]/../../../..//input[@name=\"mobileNumber\"]"));
		element2.sendKeys("32654984");
		
		WebElement element3 = driver.findElement(By.xpath("//div[@class=\"container\"]//h2[contains(text(),'Get a car or home insurance quote today!')]/../../../..//input[@name=\"idNumber\"]"));
		element3.sendKeys("id65489");
		
		Thread.sleep(7000);
		driver.findElement(By.xpath("//div[@class=\"container\"]//h2[contains(text(),'Get a car or home insurance quote today!')]/../../../..//span[contains(text(),\"Call me back\")]/../..")).click();
		
		Thread.sleep(7000);
		
		System.out.println("navigation page title is== "+driver.getTitle());
		
		Thread.sleep(3000);
		
		File src21=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		try {
			FileUtils.copyFile(src21, new File("D:\\POC\\DiscoveryPOC\\src\\output_vitalityWorks\\Up to 350.png"));
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		
		
	}

}
